import { Component } from '@angular/core';

@Component({
  selector: 'app-verify-app',
  templateUrl: './verify-app.component.html',
  styleUrls: ['./verify-app.component.css']
})
export class VerifyAppComponent {

}
