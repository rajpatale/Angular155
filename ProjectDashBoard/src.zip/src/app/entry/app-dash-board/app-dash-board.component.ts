import { Component } from '@angular/core';

@Component({
  selector: 'app-app-dash-board',
  templateUrl: './app-dash-board.component.html',
  styleUrls: ['./app-dash-board.component.css']
})
export class AppDashBoardComponent {

}
